<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'shop');
define('DB_USER', 'staff');
define('DB_PASSWORD', 'password');

// define('DB_HOST', 'mysql402.phy.lolipop.lan');
// define('DB_NAME', 'LAA1671269-myshop');
// define('DB_USER', 'LAA1671269');
// define('DB_PASSWORD', 'Tarabagani119');
